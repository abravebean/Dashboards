# React Cities

1. fork this repository to your github
2. git clone yourGitHubrepoURL
3. cd react-cities
4. npm i

All work will be done in App.js no other components should be created